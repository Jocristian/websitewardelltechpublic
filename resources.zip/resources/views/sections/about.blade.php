<section id="about" class="gap">
    <div class="container">
        <div class="heading sec-title-animation animation-style2">
            <span class="title-animation">Website that brings leads </span>
            <h2 class="title-animation">Presenting the Best No-code Website Solution</h2>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="presenting two">
                    <div>
                        <i class="flaticon-maintenance"></i>
                    </div>
                    <div>
                        <h3>State of the art Facility</h3>
                        <p>A custom logo design is a crucial part of your overall branding process. Your logo design is
                            a significant.</p>
                    </div>
                </div>
                <div class="presenting">
                    <div>
                        <i class="flaticon-helpdesk"></i>
                    </div>
                    <div>
                        <h3>Superior world class services</h3>
                        <p>A custom logo design is a crucial part of your overall branding process. Your logo design is
                            a significant.</p>
                    </div>
                </div>
                <div class="presenting">
                    <div>
                        <i class="flaticon-cursor"></i>
                    </div>
                    <div>
                        <h3>Create professional website</h3>
                        <p class="mb-0">A custom logo design is a crucial part of your overall branding process. Your
                            logo design is a significant.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="presenting">
                    <div>
                        <i class="flaticon-consulting"></i>
                    </div>
                    <div>
                        <h3>Certified expert consultants </h3>
                        <p>A custom logo design is a crucial part of your overall branding process. Your logo design is
                            a significant.</p>
                    </div>
                </div>
                <div class="presenting">
                    <div>
                        <i class="flaticon-programming"></i>
                    </div>
                    <div>
                        <h3>No extra code required</h3>
                        <p>A custom logo design is a crucial part of your overall branding process. Your logo design is
                            a significant.</p>
                    </div>
                </div>
                <div class="presenting">
                    <div>
                        <i class="flaticon-subscribe"></i>
                    </div>
                    <div>
                        <h3>All-inclusive subscription</h3>
                        <p class="mb-0">A custom logo design is a crucial part of your overall branding process. Your
                            logo design is a significant.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
