<div id="scroll-percentage"><span id="scroll-percentage-value"></span></div>
