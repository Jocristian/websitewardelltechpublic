<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WardellTech</title>
    <link rel="icon" href="/img/headingW.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.css">
    <link rel="stylesheet" href="assets/css/profile.css">

</head>
<body>
@yield('css')
@yield('profile')
@yield('myservices')
@yield('mytransactions')
@yield('mychats')
<script src="{{ asset('assets/js/main.js') }}"></script>
</body>