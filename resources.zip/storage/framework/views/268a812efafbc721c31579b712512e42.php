<?php $__env->startSection("profile"); ?>
<section>
   <!--=============== HEADER ===============-->
   <header class="header" id="header">
         <div class="header__container">
            <a href="<?php echo e(route('home')); ?>" class="header__logo">
               <span>WardellTech</span>
            </a>
            
            <button class="header__toggle" id="header-toggle">
               <i class="ri-menu-line"></i>
            </button>
         </div>
         <!-- Bootstrap CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
      <!-- Bootstrap JS (for modal functionality) -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
      <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
      <style>
         .profile-card {
            padding: 25px;
            border-radius: 12px;
            margin: 50px auto;
         }
         .profile-photo {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
            display: block;
            margin: 0 auto 15px auto;
         }
         .form-select:focus {
            background-color: #444;
            box-shadow: none;
            color: white;
         }
         .btn-primary {
            background-color: #4CAF50;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
         }
         .btn-primary:hover {
            background-color: #43a047;
         }
      </style>
   </header>

   <!--=============== SIDEBAR ===============-->
   <nav class="sidebar" id="sidebar">
      <div class="sidebar__container">
         <div class="sidebar__user">
            <div class="sidebar__img">
            <img 
               src="<?php echo e(Auth::user()->profile_photo ? asset('storage/' . Auth::user()->profile_photo) : 'https://ui-avatars.com/api/?name=' . urlencode(Auth::user()->name) . '&background=0D8ABC&color=fff'); ?>" 
               style="height: 100%; width: auto;" 
               alt="profile image">
            </div>

            <div class="sidebar__info">
               <h3> <?php echo e(auth()-> user()->name); ?></h3>
               <span> <?php echo e(auth()-> user()->email); ?> </span>
            </div>
         </div>

         <div class="sidebar__content">
            <div>
               <h3 class="sidebar__title">MANAGE</h3>

               <div class="sidebar__list">

                  <a href="" class="sidebar__link">
                     <i class="ri-pie-chart-2-fill"></i>
                     <span>Dashboard</span>
                  </a>


                  <a href="<?php echo e(route('profile')); ?>" class="sidebar__link <?php echo e(request()->is('profile') ? 'active-link' : ''); ?>">
                     <i class="ri-pie-chart-2-fill"></i>
                     <span>Edit Profile</span>
                  </a>

                  <a href="<?php echo e(route('mytransactions')); ?>" class="sidebar__link <?php echo e(request()->is('mytransactions') ? 'active-link' : ''); ?>">
                     <i class="ri-arrow-up-down-line"></i>
                     <span>Recent Transactions</span>
                  </a>

                  <?php if(auth() -> user() -> role == 'freelancer' ): ?>
                  <a href="myservices" class="sidebar__link">
                        <i class="ri-mail-unread-fill"></i>
                        <span>My Services</span>
                     </a>

                     <a href="<?php echo e(route('mymessages')); ?>" class="sidebar__link <?php echo e(request()->is('mymessages') ? 'active-link' : ''); ?>">
                        <i class="ri-mail-unread-fill"></i>
                        <span>My Messages</span>
                     </a>
                  <?php endif; ?>

               </div>
            </div>
            <div class="sidebar__actions">
         <div class="sidebar__actions">
            <form action="<?php echo e(route('logout')); ?>" method="POST">
               <?php echo csrf_field(); ?>
               <button class="sidebar__link">
                  <i class="ri-logout-box-r-fill"></i>
                  <span>Log Out</span>
               </button>
            </form>
         </div>
      </div>
   </nav>
   <!--=============== MAIN ===============-->
   <main class="main container" id="main">
         <div class="profile-card">
         <form action="<?php echo e(route('profile.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Profile Photo Preview -->
            <?php if(Auth::user()->profile_photo): ?>
                  <img src="<?php echo e(asset('storage/' . Auth::user()->profile_photo)); ?>" class="profile-photo">
            <?php else: ?>
                  <img src="<?php echo e(asset('https://ui-avatars.com/api/?name=' . urlencode(Auth::user()->name) . '&background=0D8ABC&color=fff')); ?>" class="profile-photo">
            <?php endif; ?>

            <!-- Full Name -->
            <div class="mb-3">
                  <label class="form-label"><strong>Full Name</strong></label>
                  <input type="text" name="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>" required>
            </div>

            <!-- Email -->
            <div class="mb-3">
                  <label class="form-label"><strong>Email</strong></label>
                  <input type="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>" readonly>
            </div>

            <!-- Phone Number -->
            <div class="mb-3">
                  <label class="form-label"><strong>Phone Number</strong></label>
                  <input type="text" name="phone_number" class="form-control" value="<?php echo e(Auth::user()->phone_number); ?>" required>
            </div>

            <!-- About Me -->
            <div class="mb-3">
               <label class="form-label"><strong>About Me</strong></label>
               <textarea name="about_me" class="form-control" rows="4" placeholder="Tell us something about yourself"><?php echo e(Auth::user()->about_me); ?></textarea>
            </div>


            <!-- Profile Photo -->
            <div class="mb-3">
                  <label class="form-label"><strong>Profile Photo</strong></label>
                  <input type="file" name="profile_photo" class="form-control">
            </div>

            <!-- Online Status -->
            <div class="mb-3">
                  <label class="form-label"><strong>Online Status</strong></label>
                  <select name="is_online" class="form-select">
                     <option value="1" <?php echo e(Auth::user()->is_online ? 'selected' : ''); ?>>Online</option>
                     <option value="0" <?php echo e(!Auth::user()->is_online ? 'selected' : ''); ?>>Offline</option>
                  </select>
            </div>

            <!-- Submit -->
            <button type="submit" class="btn btn-primary w-100">Save Changes</button>
         </form>
         </div>
   </main>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\WebsiteWardellt\WebsiteWardellt\resources\views/sections/profile.blade.php ENDPATH**/ ?>