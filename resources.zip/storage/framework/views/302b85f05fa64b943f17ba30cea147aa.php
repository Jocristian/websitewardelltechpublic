<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WardellTech</title>
    <link rel="icon" href="/img/headingW.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.css">
    <link rel="stylesheet" href="assets/css/profile.css">

</head>
<body>
<?php echo $__env->yieldContent('css'); ?>
<?php echo $__env->yieldContent('profile'); ?>
<?php echo $__env->yieldContent('myservices'); ?>
<?php echo $__env->yieldContent('mytransactions'); ?>
<?php echo $__env->yieldContent('mychats'); ?>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
</body><?php /**PATH D:\XAMPP\htdocs\WebsiteWardellt\WebsiteWardellt\resources\views/layouts/profile.blade.php ENDPATH**/ ?>