<header id="stickyHeader">
    <div class="container">
        <div class="top-bar" style="height: 120px;">
            <div class="logo">
                <a href="<?php echo e(route('home')); ?>">
                    <img alt="logo-heading" src="/img/logokunW.png">
                </a>`
            </div>
            <nav class="navbar">
                <ul class="navbar-links">
                    <li class="navbar-dropdown menu-item-children">
                    </li>
                    <li class="navbar-dropdown">
                        <a href="/"> About </a>
                    </li>
                    <li class="navbar-dropdown">
                        <a href="<?php echo e(url('/services')); ?>">Services</a>
                    </li>
                    <li class="navbar-dropdown">
                        <a href="<?php echo e(url('/freelancers')); ?>">Freelancer</a>
                    </li>
                    <li class="navbar-dropdwon">
                        <a href="<?php echo e(auth()->check() ? url('/profile') : url('/login')); ?>"><i class="fas fa-user-circle" style="margin-top: 4px;"></i>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</header>
<?php /**PATH D:\XAMPP\htdocs\WebsiteWardellt\WebsiteWardellt\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>