<section class="gap clients-section">
    <div class="container">
        <div class="heading sec-title-animation animation-style2">
            <span class="title-animation">Client’s Reviews </span>
            <h2 class="title-animation">What our awesome clients say</h2>
        </div>
    </div>
    <div class="marquee-two">
        <div class="marquee-box-one">
            <div class="marquee-content-one">
                <div class="clients">
                    <div class="clients-img">
                        <img src="/img/clients-1.jpg" alt="img">
                        <div>
                            <div class="d-flex">
                                <h3>Luke Maccormick</h3>
                                <a href="JavaScript:void(0)"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            <ul class="star">
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                    <p>“This is one the most transparent referral programs I’ve ever used before. Besides, it’s
                        double-sided and it lets me not only share a great service with my friends, but to earn and make
                        them earn as well. I earned money by sharing referral link on Facebook.”</p>
                </div>
                <div class="clients">
                    <div class="clients-img">
                        <img src="/img/clients-2.jpg" alt="img">
                        <div>
                            <div class="d-flex">
                                <h3>Luke Maccormick</h3>
                                <a href="JavaScript:void(0)"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            <ul class="star">
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                    <p>“This is one the most transparent referral programs I’ve ever used before. Besides, it’s
                        double-sided and it lets me not only share a great service with my friends, but to earn and make
                        them earn as well. I earned money by sharing referral link on Facebook.”</p>
                </div>
                <div class="clients">
                    <div class="clients-img">
                        <img src="/img/clients-3.jpg" alt="img">
                        <div>
                            <div class="d-flex">
                                <h3>Luke Maccormick</h3>
                                <a href="JavaScript:void(0)"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            <ul class="star">
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                    <p>“This is one the most transparent referral programs I’ve ever used before. Besides, it’s
                        double-sided and it lets me not only share a great service with my friends, but to earn and make
                        them earn as well. I earned money by sharing referral link on Facebook.”</p>
                </div>
            </div>
            <div class="marquee-content-one">
                <div class="clients">
                    <div class="clients-img">
                        <img src="/img/clients-4.jpg" alt="img">
                        <div>
                            <div class="d-flex">
                                <h3>Luke Maccormick</h3>
                                <a href="JavaScript:void(0)"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            <ul class="star">
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                    <p>“This is one the most transparent referral programs I’ve ever used before. Besides, it’s
                        double-sided and it lets me not only share a great service with my friends, but to earn and make
                        them earn as well. I earned money by sharing referral link on Facebook.”</p>
                </div>
                <div class="clients">
                    <div class="clients-img">
                        <img src="/img/clients-5.jpg" alt="img">
                        <div>
                            <div class="d-flex">
                                <h3>Luke Maccormick</h3>
                                <a href="JavaScript:void(0)"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            <ul class="star">
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                    <p>“This is one the most transparent referral programs I’ve ever used before. Besides, it’s
                        double-sided and it lets me not only share a great service with my friends, but to earn and make
                        them earn as well. I earned money by sharing referral link on Facebook.”</p>
                </div>
                <div class="clients">
                    <div class="clients-img">
                        <img src="/img/clients-2.jpg" alt="img">
                        <div>
                            <div class="d-flex">
                                <h3>Luke Maccormick</h3>
                                <a href="JavaScript:void(0)"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            <ul class="star">
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                    <p>“This is one the most transparent referral programs I’ve ever used before. Besides, it’s
                        double-sided and it lets me not only share a great service with my friends, but to earn and make
                        them earn as well. I earned money by sharing referral link on Facebook.”</p>
                </div>
            </div>
        </div>
    </div>
    <div class="marquee-three">
        <div class="marquee-box-one">
            <div class="marquee-content-two">
                <div class="clients">
                    <div class="clients-img">
                        <img src="/img/clients-4.jpg" alt="img">
                        <div>
                            <div class="d-flex">
                                <h3>Luke Maccormick</h3>
                                <a href="JavaScript:void(0)"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            <ul class="star">
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                    <p>“This is one the most transparent referral programs I’ve ever used before. Besides, it’s
                        double-sided and it lets me not only share a great service with my friends, but to earn and make
                        them earn as well. I earned money by sharing referral link on Facebook.”</p>
                </div>
                <div class="clients">
                    <div class="clients-img">
                        <img src="/img/clients-5.jpg" alt="img">
                        <div>
                            <div class="d-flex">
                                <h3>Luke Maccormick</h3>
                                <a href="JavaScript:void(0)"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            <ul class="star">
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                    <p>“This is one the most transparent referral programs I’ve ever used before. Besides, it’s
                        double-sided and it lets me not only share a great service with my friends, but to earn and make
                        them earn as well. I earned money by sharing referral link on Facebook.”</p>
                </div>
                <div class="clients">
                    <div class="clients-img">
                        <img src="/img/clients-2.jpg" alt="img">
                        <div>
                            <div class="d-flex">
                                <h3>Luke Maccormick</h3>
                                <a href="JavaScript:void(0)"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            <ul class="star">
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                    <p>“This is one the most transparent referral programs I’ve ever used before. Besides, it’s
                        double-sided and it lets me not only share a great service with my friends, but to earn and make
                        them earn as well. I earned money by sharing referral link on Facebook.”</p>
                </div>
            </div>
            <div class="marquee-content-two">
                <div class="clients">
                    <div class="clients-img">
                        <img src="/img/clients-1.jpg" alt="img">
                        <div>
                            <div class="d-flex">
                                <h3>Luke Maccormick</h3>
                                <a href="JavaScript:void(0)"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            <ul class="star">
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                    <p>“This is one the most transparent referral programs I’ve ever used before. Besides, it’s
                        double-sided and it lets me not only share a great service with my friends, but to earn and make
                        them earn as well. I earned money by sharing referral link on Facebook.”</p>
                </div>
                <div class="clients">
                    <div class="clients-img">
                        <img src="/img/clients-2.jpg" alt="img">
                        <div>
                            <div class="d-flex">
                                <h3>Luke Maccormick</h3>
                                <a href="JavaScript:void(0)"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            <ul class="star">
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                    <p>“This is one the most transparent referral programs I’ve ever used before. Besides, it’s
                        double-sided and it lets me not only share a great service with my friends, but to earn and make
                        them earn as well. I earned money by sharing referral link on Facebook.”</p>
                </div>
                <div class="clients">
                    <div class="clients-img">
                        <img src="/img/clients-3.jpg" alt="img">
                        <div>
                            <div class="d-flex">
                                <h3>Luke Maccormick</h3>
                                <a href="JavaScript:void(0)"><i class="fa-brands fa-twitter"></i></a>
                            </div>
                            <ul class="star">
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                                <li><i class="fa-solid fa-star"></i></li>
                            </ul>
                        </div>
                    </div>
                    <p>“This is one the most transparent referral programs I’ve ever used before. Besides, it’s
                        double-sided and it lets me not only share a great service with my friends, but to earn and make
                        them earn as well. I earned money by sharing referral link on Facebook.”</p>
                </div>
            </div>

        </div>
    </div>
    <ul class="shaps-img">
        <li><img src="/img/shaps-1.png" alt="img"></li>
        <li><img src="/img/shaps-2.png" alt="img"></li>
    </ul>
</section>
<?php /**PATH D:\XAMPP\htdocs\WebsiteWardellt\WebsiteWardellt\resources\views/sections/reviews.blade.php ENDPATH**/ ?>