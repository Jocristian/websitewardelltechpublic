<section class="gap no-top section-client ">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="count-style">
                    <h2 data-max="20"><sup>M</sup></h2>
                    <h4>Happy Client’s Satisfaction</h4>
                    <p>Customer happiness is the level of loyalty and satisfaction that your customers experience</p>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="count-style two">
                    <h2 data-max="164"><sup>K</sup></h2>
                    <h4>Website Grow Business</h4>
                    <p>Customer happiness is the level of loyalty and satisfaction that your customers experience</p>
                </div>
            </div>
        </div>
    </div>
    <ul class="shaps-img">
        <li><img src="/img/shaps-1.png" alt="img"></li>
        <li><img src="/img/shaps-6.png" alt="img"></li>
    </ul>
</section>
<?php /**PATH D:\xampp\htdocs\wardelltech\WebsiteWardellt\resources\views/sections/statistics.blade.php ENDPATH**/ ?>