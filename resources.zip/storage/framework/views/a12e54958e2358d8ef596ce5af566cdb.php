<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WardellTech</title>
    <link rel="icon" href="/img/headingW.png">
    <link rel="stylesheet" href="assets/css/services.css">
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')([
    'node_modules/bootstrap/dist/css/bootstrap.min.css',
    'node_modules/owl.carousel/dist/assets/owl.carousel.min.css',
    'node_modules/owl.carousel/dist/assets/owl.theme.default.min.css',
    'node_modules/jquery.fancybox/source/jquery.fancybox.css',
    'resources/fonts/flaticon_mycollection.css',
    'resources/css/fontawesome.min.css',
    'resources/css/style.css',
    'resources/css/responsive.css']); ?>

    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

</head>


<?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<section class="container mx-auto px-4 py-6 mt-21" style="padding-top: 200px">
<!-- <?php dump($user, $services); ?> -->
    <div class="container py-4">
        <div class="bg-white shadow rounded p-4">
            <div class="flex items-center gap-4">
                <?php if($user->profile_photo): ?>
                    <img src="<?php echo e(asset('storage/' . $user->profile_photo)); ?>" alt="Profile Photo" class="w-24 h-24 rounded-full object-cover">
                <?php else: ?>
                    <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($user->name)); ?>" alt="Avatar" class="w-24 h-24 rounded-full">
                <?php endif; ?>

                <div>
                    <h2 class="text-2xl font-bold"><?php echo e($user->name); ?></h2>
                    <p class="text-muted"><?php echo e($user->email); ?></p>
                    <p class="text-muted">📱 <?php echo e($user->phone_number); ?></p>
                    <?php if(isset($user->about_me)): ?>
                        <p class="mt-2"><?php echo e($user->about_me); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="mt-5">
            <h3 class="text-xl font-semibold mb-3">Services Offered</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(url('services/' . $service->service_id)); ?>">
                    <div class="bg-white shadow-md rounded-lg p-4">
                        <img src="<?php echo e(asset('storage/' . $service->photo)); ?>" alt="<?php echo e($service->overview . ' ' . $service->service_id); ?>" class="w-full max-h-40 object-cover rounded-lg">
                        <h2 class="text-xl font-bold mt-2"><?php echo e(\Illuminate\Support\Str::limit($service->overview, 35)); ?></h2>
                        <div class="flex justify-between items-center mt-2">
                        <span class="text-yellow-500">
                            ⭐ <?php echo e(number_format($service->ordersWithReview->avg('rating'), 1)); ?> (<?php echo e($service->ordersWithReview->count()); ?> reviews)
                        </span>

                            <h2 class="text-gray-700">Rp.<?php echo e(number_format($service->price)); ?></h2>
                            
                        </div>
                        <span class="badge bg-secondary mt-2"><?php echo e($service->category); ?></span>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>This user has no services yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>


<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<?php /**PATH D:\XAMPP\htdocs\WebsiteWardellt\WebsiteWardellt\resources\views/pages/my-profile.blade.php ENDPATH**/ ?>